tinymce.addI18n('de', {
    'Icons': 'Icons',
    'Web Application': 'Web-Anwendung',
    'File Type': 'Dateitypen',
    'Spinner': 'Drehend',
    'Form Control': 'Formularfelder',
    'Currency': 'W&auml;hrungen',
    'Text Editor': 'Texteditor',
    'Directional': 'Richtung',
    'Video Player': 'Videoplayer',
    'Brand': 'Marken',
    'Medical': 'Medizinisch',
    'Transportation': 'Transport',
    'Gender': 'Geschlecht',
    'Payment': 'Bezahlung',
    'Chart': 'Diagramm',
    'Hand': 'Hand'
});