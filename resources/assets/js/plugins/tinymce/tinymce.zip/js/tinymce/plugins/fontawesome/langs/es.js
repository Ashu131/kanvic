tinymce.addI18n('es', {
    'Icons': 'Iconos',
    'Web Application': 'Aplicación Web',
    'File Type': 'Tipos de Fichero',
    'Spinner': 'Carga',
    'Form Control': 'Elementos de Formulario',
    'Currency': 'Divisas',
    'Text Editor': 'Editor de Texto',
    'Directional': 'Direccional',
    'Video Player': 'Reproductor de Video',
    'Brand': 'Marcas',
    'Medical': 'Médicos',
    'Transportation': 'Transportes',
    'Gender': 'Géneros',
    'Payment': 'Formas de Pago',
    'Chart': 'Gráficos',
    'Hand': 'Mano'
});