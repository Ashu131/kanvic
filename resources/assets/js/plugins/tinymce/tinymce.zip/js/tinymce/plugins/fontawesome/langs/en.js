tinymce.addI18n('en', {
    'Icons': 'Icons',
    'Web Application': 'Web Application',
    'File Type': 'File Type',
    'Spinner': 'Spinner',
    'Form Control': 'Form Control',
    'Currency': 'Currency',
    'Text Editor': 'Text Editor',
    'Directional': 'Directional',
    'Video Player': 'Video Player',
    'Brand': 'Brand',
    'Medical': 'Medical',
    'Transportation': 'Transportation',
    'Gender': 'Gender',
    'Payment': 'Payment',
    'Chart': 'Chart',
    'Hand': 'Hand'
});